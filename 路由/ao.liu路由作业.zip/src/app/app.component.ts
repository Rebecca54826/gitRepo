import { Component } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent {
	// title = 'angular-homework';
	public number = 0
	public popup = false
	public btnDisabled = true
	public calculateNum
	//路由作业参数
	public tabs = [
		{
			name :'query',
			active :true,
		},
		{
			name :'dynamic',
			active :false,
		},
		{
			name :'lazy load',
			active :false,
		},
		{
			name :'carousel',
			active :false,
		}
	]

	public dynamicList = [
		{ name: "周杰伦" , eid: "jielun.zhou" },
		{ name: "吴亦凡" , eid: "yifan.wu" },
		{ name: "王一博" , eid: "yibo.wang" },
		{ name: "白敬亭" , eid: "jingting.bai" }
	]

	public queryID	//query参数
	
	public name = this.dynamicList[0].name	//动态路由tabB参数
	public eid = this.dynamicList[0].eid	//动态路由tabB参数
	public dynamicID = 0  //动态路由tabD参数

	constructor(
		private router: Router,		//依赖注入（可跳转navigate（））
		private route: ActivatedRoute,	//依赖注入订阅路由参数
	) { }
	
	//弹出框显示
	popupShow(){
		this.popup = true
	}

	//弹出框confirm是否可点
	confirmAbleFn(){
		let num = this.calculateNum

		if(Math.sqrt(num).toString().indexOf('.') < 0 && num !==''){
			this.btnDisabled = false
		}else if(Math.pow(num,1/3).toString().indexOf('.') < 0 && num !==''){
			this.btnDisabled = false
		}else{
			this.btnDisabled = true
		}
	}

	// 弹出框cancel按钮
	cancelBtn(){
		this.popup = false
	}

	//弹出框confirm按钮
	confirmBtn(){
		let resultSquare = Math.sqrt(this.calculateNum)
		let resultCube = Math.pow(this.calculateNum,1/3)

		if(resultSquare.toString().indexOf('.') < 0){
			this.number = resultSquare
			this.cancelBtn()
		}else if(resultCube.toString().indexOf('.') < 0){
			this.number = resultCube
			this.cancelBtn()
		}else{
			this.cancelBtn()
		}
	}

	//========================路由tab切换==============================
	//切换tab
	changeTab(tab,tabIndex){
		this.tabs.forEach(e => {
  			e.active = false;
  		});
  		
  		tab.active = true;

  		switch (tabIndex)
  		{
  			case 0:
  				this.name = this.dynamicList[tabIndex].name
  				this.eid = this.dynamicList[tabIndex].eid
  				this.dynamicID = tabIndex
  				this.router.navigate(['/main/tabA'],{queryParams: {queryID: this.queryID}});
  				break;

  			case 1:
  				this.queryID = tabIndex
  				this.dynamicID = tabIndex
  				this.router.navigate(['/main/tabB',this.name,this.eid])
  				break;

  			case 2:
  				this.queryID = tabIndex
  				this.name = this.dynamicList[tabIndex].name
  				this.eid = this.dynamicList[tabIndex].eid
  				this.dynamicID = tabIndex
  				this.router.navigate(['/main/tabC/child'])
  				break;

  			case 3:
  				this.queryID = tabIndex
  				this.name = this.dynamicList[tabIndex].name
  				this.eid = this.dynamicList[tabIndex].eid
  				this.router.navigate(['/main/tabD',this.dynamicID])
  				break;
  		}
	}
}
