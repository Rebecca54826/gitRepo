import { Component ,OnInit ,EventEmitter} from '@angular/core';

@Component({
	selector: 'child-first',
	templateUrl: './child_first.html',
	styleUrls: ['./child_first.css'],
	inputs: ['number'],
	outputs: ['popupShow']
})
export class child_firstComponent {
	public number: any;
	public popupShow = new EventEmitter<any>();
	
	ngOnInit() {
		console.log('this.number',this.number);
	}

	clickInput(){
		this.popupShow.emit()
	}
}
