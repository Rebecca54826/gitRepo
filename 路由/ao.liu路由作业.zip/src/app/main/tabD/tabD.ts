import { Component , OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

@Component({
	templateUrl: './tabD.html',
	styleUrls: ['./tabD.css']
})
export class tabDComponent implements OnInit {
	public dynamicID
	public imgLists = [
				{src: '../assets/images/1.jpg', status: true},
				{src: '../assets/images/2.jpg', status: false},
				{src: '../assets/images/3.jpg', status: false},
				{src: '../assets/images/4.jpg', status: false}
			]
	public cur = 0    //当前的图片序号
	public timer = null

	constructor(
		private router: Router,
		private route: ActivatedRoute
	){ 
		var that = this
		that.timer = setInterval(()=>{
			that.changePic(this.cur + 1)
		},2000)
	}

	ngOnInit() {
	    this.route.params.subscribe(params=> {
		  this.dynamicID = params.dynamicID
		  // console.log(params)
		})
	}

	//轮播
	changePic(_cur){
		this.imgLists.forEach(e =>{
	 		e.status = false
	 	})
	 	this.cur = _cur < 0 ? this.imgLists.length - 1 : (_cur > this.imgLists.length - 1 ? 0 : _cur)
	 	this.imgLists[this.cur].status = true
	}

	//鼠标移入轮播停止
	stopCarousel() {
		clearInterval(this.timer)
	}

	//鼠标移出轮播开始
	startCarousel(_cur) {
		this.timer = setInterval(()=>{
			this.changePic(this.cur + 1)
		},2000)
	}

	//跳转子路由
	navigateToChild(){
		this.router.navigate(['/main/tabD',this.dynamicID,'child'])
	}
}
