import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { tabDComponent } from './tabD';
import { childComponent } from '../child/child';


export const routes: Routes = [
	{ path: '', component: tabDComponent,
		children: [
		  { path: 'child', component: childComponent }
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})

export class RoutingModule {}

export const Components = [
    tabDComponent,
];