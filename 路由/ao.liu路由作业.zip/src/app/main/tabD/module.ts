import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoutingModule ,Components } from './route';
import { childModule } from '../child/module';


@NgModule({
  declarations: [
    ...Components,
  ],

  imports: [
    CommonModule,
    RoutingModule,
    childModule
  ],

  providers: []
})
export class Module { }
