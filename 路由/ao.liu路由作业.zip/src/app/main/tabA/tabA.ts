import { Component , OnInit} from '@angular/core';
import { ActivatedRoute} from '@angular/router';

@Component({
	templateUrl: './tabA.html',
	styleUrls: ['./tabA.css']
})
export class tabAComponent implements OnInit {
	public queryID

	constructor(
		private route: ActivatedRoute
	) { }

	ngOnInit() {
	    this.route.queryParams.subscribe(params=> {
			this.queryID = params.queryID
		})
	}
}
