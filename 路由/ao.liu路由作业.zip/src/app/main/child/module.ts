import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { childComponent } from './child';



@NgModule({
  declarations: [
    childComponent
  ],

  imports: [
    CommonModule,
  ],

  providers: []
})
export class childModule { }
