import { Component} from '@angular/core';

@Component({
	templateUrl: './child.html',
	styleUrls: ['./child.css'],
})
export class childComponent {
	
}
