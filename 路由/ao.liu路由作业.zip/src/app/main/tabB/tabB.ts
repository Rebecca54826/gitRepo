import { Component , OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
	templateUrl: './tabB.html',
	styleUrls: ['./tabB.css']
})
export class tabBComponent implements OnInit {
	public name
	public eid

	constructor(
		private route: ActivatedRoute
	) { }

	ngOnInit() {
	    this.route.params.subscribe(params=> {
		  this.name = params.name
		  this.eid = params.eid
		})
	}
}
