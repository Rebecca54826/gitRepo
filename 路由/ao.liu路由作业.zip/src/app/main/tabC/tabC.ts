import { Component } from '@angular/core';

@Component({
	templateUrl: './tabC.html',
	styleUrls: ['./tabC.css']
})
export class tabCComponent {

	constructor() { }

}
