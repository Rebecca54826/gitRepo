import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { tabCComponent } from './tabC';
import { childComponent } from '../child/child';


export const routes: Routes = [
	{ path: '', component: tabCComponent,
		children: [
		  { path: 'child', component: childComponent }
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})

export class RoutingModule {}

export const Components = [
    tabCComponent,
];