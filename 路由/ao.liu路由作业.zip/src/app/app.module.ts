import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule , HashLocationStrategy,  LocationStrategy} from '@angular/common';

import { AppComponent } from './app.component';
import { child_firstComponent } from './child_first/child_first';
import { child_secondComponent } from './child_second/child_second';
import { AppRoutingModule , Components } from './app.router';


@NgModule({
  declarations: [
    AppComponent,
    child_firstComponent,
    child_secondComponent,
    ...Components,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    AppRoutingModule,
    CommonModule,

  ],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy},
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
