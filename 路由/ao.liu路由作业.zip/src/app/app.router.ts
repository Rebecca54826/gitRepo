import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { tabAComponent } from './main/tabA/tabA';
import { tabBComponent } from './main/tabB/tabB';



export const ROUTES: Routes = [
	{ path: 'main/tabA', component: tabAComponent },
	{ path: 'main/tabB/:name/:eid', component: tabBComponent },
	{ path: 'main/tabC', loadChildren  : './main/tabC/module#Module'},
	{ path: 'main/tabD/:dynamicID', loadChildren: './main/tabD/module#Module' },// ./tabD/module 文件路径  # export class Module
	{ path: '', redirectTo: '/main/tabA', pathMatch: 'full'},
    { path: '**', component: tabAComponent }
];

@NgModule({
	imports: [RouterModule.forRoot(ROUTES)],
	exports: [RouterModule]
})

export class AppRoutingModule {}

export const Components = [
    tabAComponent,
    tabBComponent,
];