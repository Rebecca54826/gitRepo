import { Component, OnInit } from '@angular/core';
import { Router ,ActivatedRoute} from '@angular/router';
@Component({
	// selector: 'app-root',
	templateUrl: './child.coponent.html',
	styleUrls: ['./child.coponent.css']
})
export class ChildComponent implements OnInit{
	//public abs
	constructor( 
		private router: Router,//依赖注入
		private route: ActivatedRoute,//依赖注入
		 ) {

	}
	ngOnInit() {
	    this.route.queryParams.subscribe(params=> {
		  // this.queryParams = params;
		  console.log('this.route.queryParams',params);
		})
	}
	
	changeRouteFn(){
		this.router.navigate(['/child2','yangyi']);
	}

	goToCarouselFn(){
		this.router.navigate(['/carousel']);
	}
	// function abcFn(){}
}