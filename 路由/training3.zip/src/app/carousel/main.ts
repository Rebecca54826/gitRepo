import { Component, OnInit } from '@angular/core';

@Component({
	// selector: 'app-root',
	templateUrl: './main.html',
	styleUrls: ['./main.css']
})
export class MainComponent {
	title = 'carousel';
	items = [{
		imgUrl: '/src/assets/images/1.png',
		current: true
	}, {
		imgUrl: '/src/assets/images/2.png',
		current: false
	}, {
		imgUrl: '/src/assets/images/3.png',
		current: false
	}, {
		imgUrl: '/src/assets/images/4.png',
		current: false
	}, {
		imgUrl: '/src/assets/images/5.png',
		current: false
	}, {
		imgUrl: '/src/assets/images/6.png',
		current: false
	}];
	leftClickNum = 0;
	private timer;
	constructor() {
		this.autoCarousel();
	}
	changeImg(i) {
		this.clearTime();
		this.items.forEach(function(val){
			val.current = false;
		});
		this.items[i].current = true;
		this.leftClickNum = 0;
	}
	preNext(event) {
		this.clearTime();
		let length = this.items.length;
		for(let i = 0;i < length;i++) {
			if(this.items[i].current === true) {
				this.items.forEach(function(val){
					val.current = false;
				});
				if(event.target.className.indexOf('next') > 0 || event.target.className.indexOf('right') > 0) {
					if(i === length -1) {
						i = 0;
						this.items[i].current = true;
						break;
					}
					this.items[i + 1].current = true;
					this.leftClickNum = 0;
				}else if(event.target.className.indexOf('prev') > 0 || event.target.className.indexOf('left') > 0) {
					if(i === 0) {
						i = length -1;
						this.items[i].current = true;
						break;
					}
					this.items[i - 1].current = true;
					this.leftClickNum++;
				}
				break;
			}
		}
	}
	autoCarousel() {
		if(this.leftClickNum > 0) {
			this.timer = setInterval(() => {
				let length = this.items.length;
				for(let i = 0;i < length;i++) {
					if(this.items[i].current === true) {
						this.items.forEach(function(val){
							val.current = false;
						});
						if(i === 0) {
							i = length -1;
							this.items[i].current = true;
							break;
						}
						this.items[i - 1].current = true;
						break;
					}
				}
			}, 2000);
		}else {
			this.timer = setInterval(() => {
				let length = this.items.length;
				for(let i = 0;i < length;i++) {
					if(this.items[i].current === true) {
						this.items.forEach(function(val){
							val.current = false;
						});
						if(i === length -1) {
							i = 0;
							this.items[i].current = true;
							break;
						}
						this.items[i + 1].current = true;
						break;
					}
				}
			}, 2000);
		}
		
	}
	clearTime() {
		if(this.timer) {
			clearInterval(this.timer);
		}
	}
	
}