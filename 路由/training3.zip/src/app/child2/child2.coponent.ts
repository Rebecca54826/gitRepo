import { Component, OnInit } from '@angular/core';
import { Router ,ActivatedRoute} from '@angular/router';

@Component({
	// selector: 'app-root',
	templateUrl: './child2.coponent.html',
	styleUrls: ['./child2.coponent.css']
})
export class ChildtComponent implements OnInit{
	//public abs
	public username;
	constructor(
		private router: Router,//依赖注入
		private route: ActivatedRoute,//依赖注入
		) {}
	
	ngOnInit() {
		this.route.params.subscribe((params) => {

			this.username = params.username;
			console.log(params,params.username);
		});
	}

	changeRouteFn(){
		this.router.navigate(['/child'],{queryParams: {key: 'value'}});
	}

	goToCarouselFn(){
		this.router.navigate(['/carousel']);
	}
	// function abcFn(){}
}