import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CommonModule , HashLocationStrategy,  LocationStrategy} from '@angular/common';

//add route api
import { AppRoutingModule ,Components} from './app.route';
// import { ChildComponent } from './child/child.coponent';
// import { ChildtComponent } from './child2/child2.coponent';

@NgModule({
  declarations: [
    AppComponent,
    ...Components,//es6  扩展运算符
    // ChildComponent,
    // ChildtComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule
    // RouterModule
  ],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy},
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
