import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import { ChildComponent } from './child/child.coponent';
import { ChildtComponent } from './child2/child2.coponent';


const routes: Routes = [
    { path: 'child',    component : ChildComponent,
				// children: [
    //                 { path: '',component : '' },
    //             ],
     },
    { path: 'child2/:username',    component : ChildtComponent},
    { path: 'carousel',    loadChildren  : './carousel/Module#Module'},// ./carousel/Module 文件路径  # export class Module
    { path: '', redirectTo: '/child', pathMatch: 'full'},
    { path: '**', component: ChildComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    
})
export class AppRoutingModule {}


export const Components = [
    ChildtComponent,
    ChildComponent,
];