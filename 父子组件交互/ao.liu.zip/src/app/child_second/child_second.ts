import { Component , ViewEncapsulation ,OnInit ,EventEmitter} from '@angular/core';

@Component({
  selector: 'child-second',
  templateUrl: './child_second.html',
  styleUrls: ['./child_second.css'],
  inputs: ['number'],
  outputs: ['popupShow'],
  encapsulation: ViewEncapsulation.None
})
export class child_secondComponent {
	public number: any;
	public popupShow = new EventEmitter<any>();

	ngOnInit() {
		console.log('second-child number',this.number);
	}

	clickInput() {
		this.popupShow.emit()
	}
}
