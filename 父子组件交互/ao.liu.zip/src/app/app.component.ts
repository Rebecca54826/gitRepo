import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent {
	// title = 'angular-homework';
	public number = 0
	public popup = false
	public btnDisabled = true
	public calculateNum 

	//弹出框显示
	popupShow(){
		this.popup = true
	}

	//弹出框confirm是否可点
	confirmAbleFn(){
		let num = this.calculateNum

		if(Math.sqrt(num).toString().indexOf('.') < 0 && num !==''){
			this.btnDisabled = false
		}else if(Math.pow(num,1/3).toString().indexOf('.') < 0 && num !==''){
			this.btnDisabled = false
		}else{
			this.btnDisabled = true
		}
	}

	// 弹出框cancel按钮
	cancelBtn(){
		this.popup = false
	}

	//弹出框confirm按钮
	confirmBtn(){
		let resultSquare = Math.sqrt(this.calculateNum)
		let resultCube = Math.pow(this.calculateNum,1/3)

		if(resultSquare.toString().indexOf('.') < 0){
			this.number = resultSquare
			this.cancelBtn()
		}else if(resultCube.toString().indexOf('.') < 0){
			this.number = resultCube
			this.cancelBtn()
		}else{
			this.cancelBtn()
		}
	}
}
