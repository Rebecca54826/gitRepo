import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { child_firstComponent } from './child_first/child_first';
import { child_secondComponent } from './child_second/child_second';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    child_firstComponent,
    child_secondComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
