import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // private / public

  public title = 'yangyi';
  public number = 0;
  public tabs = [
				  		{
				  	  		name 		:'yangyi',
				  	  		active 		:true,
				  	  	},
				  	  	{
				  	  		name 		:'yangyi2',
				  	  		active 		:false,
				  	  	},
				  	  	{
				  	  		name 		:'yangyi3',
				  	  		active 		:false,
				  	  	},
				  	  	{
				  	  		name 		:'yangyi4',
				  	  		active 		:false,
				  	  	}
				  ]
  constructor() { }

  changeTab(tab,tabIndex){
  		this.tabs.forEach(e => {
  				e.active = false;
  		});
  		
  		tab.active = true;
  }
  parentResetFn(param){
  		console.log(param);
  		this.number = 0;
  }
}
  

  