import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChildComponent } from './child/child';
import { childtwoComponent } from './childtwo/childtwo';//./childtwo(文件夹名字)/childtwo.ts(文件名字 省略后缀名)
import { FormsModule }     from '@angular/forms';

@NgModule({
  declarations: [//声明组件
    AppComponent,
    ChildComponent,
    childtwoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
