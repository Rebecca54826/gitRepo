import { Component ,ViewEncapsulation ,OnInit ,EventEmitter} from '@angular/core';

@Component({
  selector: 'child-two',
  templateUrl: './childtwo.html',
  styleUrls: ['./childtwo.css'],
  // inputs: ['number:number',],
  inputs: ['number',],
  outputs: [
        'parentResetFn',
   ]
})
export class childtwoComponent implements OnInit{
	public number: any;
	public parentResetFn = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
               console.log('this.number',this.number);
  }
  resetNumberFn(){
  	var data = {
  		a:'a',
  	}
  	this.parentResetFn.emit(data);
  }
}
  

  