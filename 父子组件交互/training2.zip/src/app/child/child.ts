import { Component } from '@angular/core';

@Component({
  selector: 'child',
  templateUrl: './child.html',
  styleUrls: ['./child.css'],
  host: {
      'attr.role': 'button',
      'attr.class': 'parent_host',
      '(mouseenter)': 'onMouseEnter()'
    }
})
export class ChildComponent {
	role = 'button';
	onMouseEnter() {
	 // do work
	 this.logOneFn();
	}
  constructor() { 
  	console.log(this.role);
  }
  logOneFn(){
  	console.log(1111111)
  }

}
  

  