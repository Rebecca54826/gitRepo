import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // public title = 'angular-study';
  const that = this
  imgLists = [
  	{src: '../assets/images/1.jpg', status: true},
  	{src: '../assets/images/2.jpg', status: false},
  	{src: '../assets/images/3.jpg', status: false},
  	{src: '../assets/images/4.jpg', status: false}
  ]
  cur = 0    //当前的图片序号
  private timer = null
  

  // 点击上一张
  prev() {
  	let _cur = this.cur
  	_cur = _cur > 0 ? (-- _cur) : ( this.imgLists.length - 1 )
  	this.changePic(_cur)
  }

	// 点击下一张
  next() {
  	this.toNext()
  }

  // 下一张
  toNext(){
  	let _cur = this.cur
  	_cur = _cur < ( this.imgLists.length - 1 ) ? (++ _cur) : 0
  	this.changePic(_cur)
  }

  // 切换图片
  changePic(_cur) {
  	this.imgLists.forEach(e =>{
  		e.status = false
  	})
  	this.imgLists[_cur].status = true
  	this.cur = _cur
  }

  //点击小图标切换
  imgIndex(imgListIndex) {
  	let _cur = imgListIndex
  	this.changePic(_cur)
  }

  //定时器
	that.timer = setInterval(()=>{
		this.toNext()
	},2000)
	
	//鼠标移入轮播停止
	stopCarousel() {
  	clearInterval(this.timer)
	}

	//鼠标移出轮播开始
	startCarousel() {
		this.timer = setInterval(()=>{
			this.toNext()
		},2000)
	}
}
